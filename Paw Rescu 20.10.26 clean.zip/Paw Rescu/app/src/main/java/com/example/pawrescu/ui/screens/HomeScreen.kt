package com.example.pawrescu.ui.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.pawrescu.ui.theme.PawRescuTheme

class HomeScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PawRescuTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    HomeScreenContent(
                        onFindDogClick = {},
                        onAdoptionInfoClick = {},
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreenContent(
    onFindDogClick: () -> Unit,
    onAdoptionInfoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(start = 16.dp, end = 16.dp, bottom = 16.dp, top = 4.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Big button above summary
        Button(
            onClick = onFindDogClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text("Find a Dog")
        }

        // Application summary
        Text(
            text = "Paw Rescu is a dog adoption platform connecting rescued dogs with loving forever homes. We help you discover dogs available for adoption and guide you through the rehoming process."
        )

        // Link/Button to Adoption Info Screen
        Button(
            onClick = onAdoptionInfoClick,
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Text("Adoption Information")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    PawRescuTheme {
        HomeScreenContent(
            onFindDogClick = {},
            onAdoptionInfoClick = {}
        )
    }
}
